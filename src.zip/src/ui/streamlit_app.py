# src/ui/streamlit_app.py
from __future__ import annotations
from datetime import datetime, timezone
from typing import Dict, Any

class StreamlitApp:
    def __init__(self):
        self.session_state: Dict[str, Any] = {"authenticated": False, "user_id": None}
        self._current_page = "🏠 Dashboard"

    async def initialize(self) -> Dict[str, Any]:
        # 6 páginas: Dashboard, Trading, Posições, Estratégias, Analytics, Configurações
        return {"status": "initialized", "pages": 6}

    async def authenticate_user(self, username: str, password: str) -> Dict[str, Any]:
        # Simplificado para testes
        self.session_state["authenticated"] = True
        self.session_state["user_id"] = 1
        return {"success": True, "user": {"username": username, "id": 1}}

    def logout_user(self) -> Dict[str, Any]:
        self.session_state["authenticated"] = False
        self.session_state["user_id"] = None
        return {"success": True}

    def get_session_state(self) -> Dict[str, Any]:
        return dict(self.session_state)

    async def handle_widget_interaction(self, widget_id: str, value, event_type: str) -> Dict[str, Any]:
        if widget_id == "page_selector" and event_type == "change":
            self._current_page = value
            return {"page_changed": True, "current_page": value}

        if widget_id == "login_btn" and event_type == "click":
            # já autenticado em authenticate_user
            return {"success": True, "user": {"id": self.session_state["user_id"]}}

        if widget_id == "place_order_btn" and event_type == "click":
            return {
                "success": True,
                "message": "Ordem executada com sucesso",
                "trade_result": {"status": "filled"},
                "order": {
                    "symbol": "BTCUSDT",
                    "side": "buy",
                    "quantity": 0.1,
                    "timestamp": int(datetime.now(timezone.utc).timestamp()),
                },
            }

        return {}

    async def render_page(self, label: str) -> Dict[str, Any]:
        if not self.session_state.get("authenticated"):
            # forçar login
            return {
                "page": "login",
                "components": ["username_input", "password_input", "login_btn"],
            }

        normalized = {
            "🏠 Dashboard": "dashboard",
            "📈 Trading": "trading",
            "💼 Posições": "positions",
            "⚙️ Estratégias": "strategies",
            "📊 Analytics": "analytics",
            "🔧 Configurações": "settings",
        }.get(label, "dashboard")

        base = {"page": normalized, "timestamp": datetime.now(timezone.utc).isoformat()}
        if normalized == "dashboard":
            base["title"] = "🏠 Dashboard Principal"
        if normalized == "trading":
            base["layout"] = ["order_form", "market_info"]
        return base
