# src/bot/strategies/__init__.py
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
from typing import Dict, List, Optional

from src.indicators import EMAIndicator, RSIIndicator, StochRSIIndicator

@dataclass
class MarketData:
    symbol: str
    price: float
    timestamp: datetime
    volume: float = 0.0


class BaseStrategy:
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._risk = {
            "risk_per_trade": float(self.config.get("risk_per_trade", 0.02)),
            "max_position_size": float(self.config.get("max_position_size", 1000.0)),
            "max_daily_loss": float(self.config.get("max_daily_loss", 0.05)),
        }

    def get_risk_parameters(self) -> Dict:
        return dict(self._risk)

    def update_risk_parameters(self, params: Dict) -> None:
        if not params:
            return
        for k, v in params.items():
            self._risk[k] = v

    async def analyze(self, market_data: MarketData, price_history: List[float]) -> List:
        return []


class SMAStrategy(BaseStrategy):
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.fast_period = int(self.config.get("fast_period", 5))
        self.slow_period = int(self.config.get("slow_period", 10))

    def _calculate_sma(self, prices: List[float], period: int) -> float:
        if period <= 0 or len(prices) < period:
            return 0.0
        return sum(prices[-period:]) / period

    async def analyze(self, market_data: MarketData, price_history: List[float]) -> List:
        from src.bot.interfaces import OrderRequest, OrderSide, OrderType
        prices = (price_history or []) + [market_data.price]
        f = self._calculate_sma(prices, self.fast_period)
        s = self._calculate_sma(prices, self.slow_period)
        orders = []
        if f > s and f > 0 and s > 0:
            qty = round(self._risk["risk_per_trade"] * 1000.0 / max(market_data.price, 1.0), 6)
            orders.append(OrderRequest(market_data.symbol, OrderSide.BUY, OrderType.MARKET, qty))
        return orders


class RSIStrategy(BaseStrategy):
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.rsi_period = int(self.config.get("rsi_period", 14))
        self.oversold = float(self.config.get("oversold", 30))
        self.overbought = float(self.config.get("overbought", 70))

    def _calculate_rsi(self, prices: List[float], period: int) -> float:
        rsi = RSIIndicator(period)
        for p in prices:
            rsi.add_value(p)
        return rsi.calculate()

    async def analyze(self, market_data: MarketData, price_history: List[float]) -> List:
        from src.bot.interfaces import OrderRequest, OrderSide, OrderType
        prices = (price_history or []) + [market_data.price]
        rsi_val = self._calculate_rsi(prices, self.rsi_period)
        orders = []
        if rsi_val < self.oversold:
            qty = round(self._risk["risk_per_trade"] * 1000.0 / max(market_data.price, 1.0), 6)
            orders.append(OrderRequest(market_data.symbol, OrderSide.BUY, OrderType.MARKET, qty))
        elif rsi_val > self.overbought:
            qty = round(self._risk["risk_per_trade"] * 1000.0 / max(market_data.price, 1.0), 6)
            orders.append(OrderRequest(market_data.symbol, OrderSide.SELL, OrderType.MARKET, qty))
        return orders


class PPPVishvaStrategy(BaseStrategy):
    name = "ppp_vishva"

    def calculate_ema(self, prices: List[float], period: int) -> float:
        ind = EMAIndicator(period)
        for p in prices:
            try:
                f = float(p)
            except Exception:
                continue
            if not (math.isfinite(f)):
                continue
            ind.add_value(f)
        return ind.calculate()

    def calculate_stoch_rsi(self, prices: List[float], rsi_period: int) -> float:
        return StochRSIIndicator(rsi_period, rsi_period).calculate(prices)

    async def analyze(self, market_data: MarketData, price_history: List[float]) -> List:
        # Mantém simples; os testes só verificam que retorna lista
        return []


def get_strategy_info(name: str) -> Dict:
    key = (name or "").lower()
    if key == "sma":
        return {
            "name": "SMA",
            "description": "Simple Moving Average crossover",
            "parameters": ["fast_period", "slow_period", "risk_per_trade"],
        }
    if key == "rsi":
        return {
            "name": "RSI",
            "description": "Relative Strength Index mean-reversion",
            "parameters": ["rsi_period", "oversold", "overbought", "risk_per_trade"],
        }
    if key == "ppp_vishva":
        return {"name": "PPP Vishva", "description": "Custom composite signals", "parameters": []}
    raise ValueError("Unknown strategy")


def get_available_strategies() -> List[str]:
    return ["sma", "rsi", "ppp_vishva"]


import math
def get_strategy(name: str, config: Optional[Dict] = None):
    key = (name or "").lower()
    if key == "sma":
        return SMAStrategy(config)
    if key == "rsi":
        return RSIStrategy(config)
    if key == "ppp_vishva":
        return PPPVishvaStrategy(config)
    raise ValueError("Invalid strategy")
