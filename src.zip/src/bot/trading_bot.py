# src/bot/trading_bot.py
from __future__ import annotations
from typing import Dict, List, Optional
from datetime import datetime

from .strategies import get_strategy, MarketData
from .risk_manager import RiskManager


class TradingBot:
    def __init__(self, client_config: Dict, bybit_provider, risk_manager: Optional[RiskManager] = None):
        self.client_config = client_config or {}
        self.client_id = self.client_config.get("client_id")
        self.symbols: List[str] = list(self.client_config.get("symbols") or [])
        self.strategy = get_strategy(self.client_config.get("strategy", "sma"), self.client_config)
        self.bybit = bybit_provider
        self.risk_manager = risk_manager or RiskManager()
        self._price_history: Dict[str, List[float]] = {}

    async def _trading_cycle(self) -> None:
        for symbol in self.symbols:
            md_raw = await self.bybit.get_market_data(symbol)
            market_data = MarketData(
                symbol=symbol,
                price=md_raw.price if hasattr(md_raw, "price") else md_raw["price"],
                timestamp=md_raw.timestamp if hasattr(md_raw, "timestamp") else datetime.now(),
                volume=md_raw.volume if hasattr(md_raw, "volume") else md_raw.get("volume", 0.0),
            )

            hist = self._price_history.setdefault(symbol, [])
            hist.append(market_data.price)
            if len(hist) > 1000:
                del hist[:-500]

            orders = await self.strategy.analyze(market_data, hist[:-1])
            if not orders:
                continue

            balance = await self._maybe(self.bybit.get_account_balance())
            usdt = float((balance or {}).get("USDT", 0.0))

            for order in orders:
                # gate de risco: não mandar ordem se saldo não cobre custo
                est_cost = float(order.quantity) * float(market_data.price)
                if not self.risk_manager.can_place_order(usdt_balance=usdt, estimated_cost=est_cost):
                    continue
                await self.bybit.place_order(symbol, order.side, order.quantity)

    async def _maybe(self, obj):
        if hasattr(obj, "__await__"):
            return await obj
        return obj
