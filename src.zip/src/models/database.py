# src/models/database.py
from __future__ import annotations
from typing import Dict, List, Tuple, Optional

class DatabaseManager:
    """Implementação simples em memória que atende aos testes."""

    def __init__(self):
        self._users: Dict[int, Dict] = {}
        self._next_user_id = 1

        self._logs: List[Dict] = []
        self._next_log_id = 1

        # (symbol, timeframe) -> List[candle]
        self._market_data: Dict[Tuple[str, str], List[Dict]] = {}

    # ---------- Users ----------
    async def create_user(self, username: str, email: str, password_hash: str) -> Dict:
        uid = self._next_user_id
        self._next_user_id += 1
        user = {"id": uid, "username": username, "email": email, "password_hash": password_hash}
        self._users[uid] = user
        return dict(user)

    async def get_user(self, user_id: int) -> Optional[Dict]:
        u = self._users.get(int(user_id))
        return dict(u) if u else None

    # ---------- Logs ----------
    async def log_message(self, level: str, message: str, source: str, user_id: Optional[int] = None, extra: Optional[Dict] = None) -> int:
        lid = self._next_log_id
        self._next_log_id += 1
        entry = {
            "id": lid,
            "level": level,
            "message": message,
            "source": source,
            "user_id": user_id,
            "extra": extra or {},
        }
        self._logs.append(entry)
        return lid

    async def get_logs(self, limit: int = 100) -> List[Dict]:
        # mais recente primeiro
        return [dict(x) for x in reversed(self._logs[-limit:])]

    # ---------- Market data ----------
    async def store_market_data(self, symbol: str, timeframe: str, candles: List[Dict]) -> int:
        key = (symbol, timeframe)
        bucket = self._market_data.setdefault(key, [])
        for c in candles:
            bucket.append({
                "timestamp": int(c["timestamp"]),
                "open": float(c["open"]),
                "high": float(c["high"]),
                "low": float(c["low"]),
                "close": float(c["close"]),
                "volume": float(c["volume"]),
            })
        return len(candles)

    async def get_market_data(self, symbol: str, timeframe: str, limit: int = 100) -> List[Dict]:
        key = (symbol, timeframe)
        items = list(self._market_data.get(key, []))
        items.sort(key=lambda x: x["timestamp"], reverse=True)
        return [dict(x) for x in items[:limit]]
