# src/indicators.py
from __future__ import annotations
import math
from typing import List, Dict, Iterable

class BaseIndicator:
    def __init__(self, period: int, name: str = "BaseIndicator"):
        self.period = int(period)
        self.name = name
        self.data: List[float] = []

    def add_value(self, value: float) -> None:
        try:
            v = float(value)
        except Exception:
            return
        if math.isnan(v) or math.isinf(v):
            return
        self.data.append(v)

    def is_ready(self) -> bool:
        return len(self.data) >= self.period


class EMAIndicator(BaseIndicator):
    def __init__(self, period: int):
        super().__init__(period, "EMA")
        self._ema: float | None = None
        self._mult = 2.0 / (self.period + 1.0)

    def add_value(self, value: float) -> None:
        super().add_value(value)
        if not self.data:
            return
        v = self.data[-1]
        if self._ema is None:
            if len(self.data) >= self.period:
                self._ema = sum(self.data[-self.period:]) / self.period
        else:
            self._ema = (v - self._ema) * self._mult + self._ema

    def calculate(self) -> float:
        return 0.0 if self._ema is None else float(self._ema)


class RSIIndicator(BaseIndicator):
    def __init__(self, period: int = 14):
        super().__init__(period, "RSI")
        self._prev: float | None = None
        self._avg_gain: float | None = None
        self._avg_loss: float | None = None
        self._rsi: float | None = None

    def add_value(self, value: float) -> None:
        super().add_value(value)
        v = self.data[-1]
        if self._prev is None:
            self._prev = v
            return

        change = v - self._prev
        gain = max(change, 0.0)
        loss = max(-change, 0.0)

        if len(self.data) <= self.period:
            # construção da média inicial
            self._avg_gain = (self._avg_gain or 0.0) + gain
            self._avg_loss = (self._avg_loss or 0.0) + loss
            if len(self.data) == self.period:
                self._avg_gain /= self.period
                self._avg_loss /= self.period
                if self._avg_loss == 0:
                    self._rsi = 100.0
                else:
                    rs = self._avg_gain / self._avg_loss
                    self._rsi = 100.0 - (100.0 / (1.0 + rs))
        else:
            # suavização de Wilder
            self._avg_gain = ((self._avg_gain or 0.0) * (self.period - 1) + gain) / self.period
            self._avg_loss = ((self._avg_loss or 0.0) * (self.period - 1) + loss) / self.period
            if self._avg_loss == 0:
                self._rsi = 100.0
            else:
                rs = self._avg_gain / self._avg_loss
                self._rsi = 100.0 - (100.0 / (1.0 + rs))

        self._prev = v

    def calculate(self) -> float:
        return 50.0 if self._rsi is None else float(self._rsi)


class ATRIndicator(BaseIndicator):
    def __init__(self, period: int = 14):
        super().__init__(period, "ATR")
        self._highs: List[float] = []
        self._lows: List[float] = []
        self._closes: List[float] = []

    def add_ohlc(self, high: float, low: float, close: float) -> None:
        self._highs.append(float(high))
        self._lows.append(float(low))
        self._closes.append(float(close))

    def add_ohlc_data(self, candles: Iterable[Dict]) -> None:
        for c in candles:
            self.add_ohlc(c["high"], c["low"], c["close"])

    def calculate(self) -> float:
        n = len(self._closes)
        if n < 2:
            return 0.0

        trs: List[float] = []
        prev_close = self._closes[0]
        for i in range(1, n):
            high = self._highs[i]
            low = self._lows[i]
            tr = max(high - low, abs(high - prev_close), abs(prev_close - low))
            trs.append(tr)
            prev_close = self._closes[i]

        if not trs:
            return 0.0

        if len(trs) <= self.period:
            return sum(trs) / len(trs)

        atr = sum(trs[: self.period]) / self.period
        for tr in trs[self.period :]:
            atr = ((self.period - 1) * atr + tr) / self.period
        return float(atr)


class UTBotIndicator(BaseIndicator):
    def __init__(self, period: int = 14, multiplier: float = 2.0):
        super().__init__(period, "UTBot")
        self.multiplier = float(multiplier)
        self._atr = ATRIndicator(period)

    def add_ohlc(self, high: float, low: float, close: float) -> None:
        self._atr.add_ohlc(high, low, close)
        super().add_value(close)

    def calculate_signals(self, closes: List[float]) -> List[str]:
        # Implementação simples de trailing stop com ATR
        closes = [float(c) for c in closes if c is not None and math.isfinite(float(c))]
        if len(closes) < self.period + 1:
            return []

        # reconstroi ATR de forma simples
        self._atr._highs.clear(); self._atr._lows.clear(); self._atr._closes.clear()
        for i in range(1, len(closes)):
            c, p = closes[i], closes[i - 1]
            self._atr.add_ohlc(max(c, p), min(c, p), c)

        atr = self._atr.calculate()
        signals: List[str] = []
        stop: float | None = None

        for c in closes[-(self.period + 1) :]:
            if stop is None:
                stop = c - atr * self.multiplier
                continue
            if c < stop:
                signals.append("sell")
                stop = c + atr * self.multiplier
            elif c > stop:
                signals.append("buy")
                stop = c - atr * self.multiplier

        return signals


class EWOIndicator(BaseIndicator):
    def __init__(self, fast_period: int = 5, slow_period: int = 35):
        super().__init__(fast_period, "EWO")
        self.fast = EMAIndicator(fast_period)
        self.slow = EMAIndicator(slow_period)
        self._value: float | None = None

    def add_value(self, value: float) -> None:
        self.fast.add_value(value)
        self.slow.add_value(value)
        self._value = self.fast.calculate() - self.slow.calculate()

    def calculate(self) -> float:
        return 0.0 if self._value is None else float(self._value)


class StochRSIIndicator(BaseIndicator):
    def __init__(self, rsi_period: int = 14, stoch_period: int = 14):
        super().__init__(stoch_period, "StochRSI")
        self.rsi_period = int(rsi_period)
        self.stoch_period = int(stoch_period)

    def calculate(self, prices: List[float]) -> float:
        clean = [float(p) for p in prices if p is not None and math.isfinite(float(p))]
        if len(clean) < self.rsi_period + 1:
            return 0.5

        rsi = RSIIndicator(self.rsi_period)
        rsi_vals: List[float] = []
        for p in clean:
            rsi.add_value(p)
            rsi_vals.append(rsi.calculate())

        window = rsi_vals[-self.stoch_period :]
        if not window:
            return 0.5

        lo, hi = min(window), max(window)
        if hi - lo == 0:
            return 0.5
        return (rsi_vals[-1] - lo) / (hi - lo)


class HeikinAshiIndicator:
    def __init__(self):
        self.open: List[float] = []
        self.high: List[float] = []
        self.low: List[float] = []
        self.close: List[float] = []

    def set_ohlc(self, open_: List[float], high: List[float], low: List[float], close: List[float]) -> None:
        self.open = [float(x) for x in open_]
        self.high = [float(x) for x in high]
        self.low = [float(x) for x in low]
        self.close = [float(x) for x in close]

    def calculate_candles(self) -> List[Dict[str, float]]:
        n = len(self.close)
        candles: List[Dict[str, float]] = []
        if n == 0:
            return candles

        ha_open = (self.open[0] + self.close[0]) / 2.0
        for i in range(n):
            o, h, l, c = self.open[i], self.high[i], self.low[i], self.close[i]
            ha_close = (o + h + l + c) / 4.0
            if i > 0:
                ha_open = (candles[-1]["open"] + candles[-1]["close"]) / 2.0
            ha_high = max(h, ha_open, ha_close)
            ha_low = min(l, ha_open, ha_close)
            candles.append({"open": ha_open, "high": ha_high, "low": ha_low, "close": ha_close})
        return candles
