"""
Dashboard module
"""