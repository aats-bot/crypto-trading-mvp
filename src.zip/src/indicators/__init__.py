# AUTOGERADO por quick_fix.py
# Implementações mínimas compatíveis com os testes
from __future__ import annotations
from typing import List, Optional

class BaseIndicator:
    def __init__(self, period: int):
        self.period = int(period)
        self._data: List[float] = []

    def add_data(self, value: float):
        self._data.append(float(value))

    def get_data(self) -> List[float]:
        return list(self._data)

    def is_ready(self) -> bool:
        return len(self._data) >= self.period

    # Nos testes, BaseIndicator pode ser instanciado;
    # então não deixamos como . Levanta no runtime se usado.
    def calculate(self, *args, **kwargs):
        raise NotImplementedError("Implement in subclass")

class EMAIndicator(BaseIndicator):
    def __init__(self, period: int):
        super().__init__(period)
        self.value: Optional[float] = None

    def calculate(self, data: Optional[List[float]] = None) -> Optional[float]:
        seq = list(self._data if data is None else data)
        if not seq:
            return None
        k = 2.0 / (self.period + 1.0)
        ema = float(seq[0])
        for x in seq[1:]:
            ema = float(x) * k + ema * (1 - k)
        self.value = ema
        return ema

class RSIIndicator(BaseIndicator):
    def __init__(self, period: int = 14):
        super().__init__(period)

    def calculate(self, data: Optional[List[float]] = None) -> Optional[float]:
        seq = list(self._data if data is None else data)
        if len(seq) < self.period + 1:
            return None
        gains, losses = [], []
        for i in range(1, len(seq)):
            delta = float(seq[i]) - float(seq[i-1])
            gains.append(max(delta, 0.0))
            losses.append(abs(min(delta, 0.0)))
        # médias simples nos últimos 'period'
        g = sum(gains[-self.period:]) / self.period
        l = sum(losses[-self.period:]) / self.period
        if l == 0:
            return 100.0
        rs = g / l
        return 100.0 - (100.0 / (1.0 + rs))

class ATRIndicator(BaseIndicator):
    # Espera-se add_ohlc_data e calculate
    def __init__(self, period: int = 14):
        super().__init__(period)
        self._ohlc = []  # (high, low, close)

    def add_ohlc_data(self, high: float, low: float, close: float):
        self._ohlc.append((float(high), float(low), float(close)))

    def calculate(self, data=None) -> Optional[float]:
        if len(self._ohlc) < self.period + 1:
            return None
        trs = []
        prev_close = self._ohlc[0][2]
        for (h, l, c) in self._ohlc[1:]:
            tr = max(h - l, abs(h - prev_close), abs(l - prev_close))
            trs.append(tr)
            prev_close = c
        if len(trs) < self.period:
            return None
        # média simples dos últimos 'period'
        return sum(trs[-self.period:]) / self.period

class UTBotIndicator(BaseIndicator):
    # Placeholder simples com sinais a partir de variação percentual + ATR opcional
    def __init__(self, period: int = 14, multiplier: float = 2.0):
        super().__init__(period)
        self.multiplier = float(multiplier)

    def calculate_signals(self, prices: List[float]) -> List[str]:
        if len(prices) < self.period + 1:
            return []
        signals = []
        for i in range(1, len(prices)):
            change = (prices[i] - prices[i-1]) / prices[i-1] if prices[i-1] else 0.0
            if change > 0.005 * self.multiplier:
                signals.append("buy")
            elif change < -0.005 * self.multiplier:
                signals.append("sell")
            else:
                signals.append("hold")
        return signals

class EWOIndicator(BaseIndicator):
    # Elliot Wave Oscillator = EMA(fast) - EMA(slow)
    def __init__(self, fast_period: int = 5, slow_period: int = 35):
        super().__init__(fast_period)  # só para manter 'period' existente
        self.fast_period = int(fast_period)
        self.slow_period = int(slow_period)

    def calculate(self, data: Optional[List[float]] = None) -> Optional[float]:
        seq = list(self._data if data is None else data)
        if len(seq) < max(self.fast_period, self.slow_period):
            return None
        def ema(seq, p):
            k = 2.0 / (p + 1.0)
            v = float(seq[0])
            for x in seq[1:]:
                v = float(x) * k + v * (1 - k)
            return v
        return ema(seq, self.fast_period) - ema(seq, self.slow_period)

class StochRSIIndicator(BaseIndicator):
    def __init__(self, rsi_period: int = 14, stoch_period: int = 14):
        super().__init__(rsi_period)
        self.rsi_period = int(rsi_period)
        self.stoch_period = int(stoch_period)

    def calculate(self, data: Optional[List[float]] = None) -> Optional[float]:
        seq = list(self._data if data is None else data)
        if len(seq) < self.rsi_period + self.stoch_period + 1:
            return None
        # série de RSI
        def rsi(vals, p):
            if len(vals) < p + 1:
                return None
            gains, losses = [], []
            for i in range(1, len(vals)):
                d = float(vals[i]) - float(vals[i-1])
                gains.append(max(d, 0.0))
                losses.append(abs(min(d, 0.0)))
            g = sum(gains[-p:]) / p
            l = sum(losses[-p:]) / p
            if l == 0: return 100.0
            rs = g / l
            return 100.0 - (100.0 / (1.0 + rs))
        rsi_series = []
        for i in range(self.rsi_period, len(seq)):
            r = rsi(seq[:i+1], self.rsi_period)
            if r is not None:
                rsi_series.append(r)
        if len(rsi_series) < self.stoch_period:
            return None
        window = rsi_series[-self.stoch_period:]
        mn, mx = min(window), max(window)
        if mx == mn:
            return 0.5  # neutro
        return (rsi_series[-1] - mn) / (mx - mn)

class HeikinAshiIndicator:
    def __init__(self):
        pass

    def calculate_candles(self, ohlc: List[dict]) -> List[dict]:
        # ohlc: [{open, high, low, close}, ...]
        ha = []
        ha_open = None
        ha_close = None
        for i, c in enumerate(ohlc):
            o, h, l, cl = float(c["open"]), float(c["high"]), float(c["low"]), float(c["close"])
            ha_close = (o + h + l + cl) / 4.0
            if i == 0:
                ha_open = (o + cl) / 2.0
            else:
                ha_open = (ha[i-1]["open"] + ha[i-1]["close"]) / 2.0
            ha_high = max(h, ha_open, ha_close)
            ha_low = min(l, ha_open, ha_close)
            ha.append({"open": ha_open, "high": ha_high, "low": ha_low, "close": ha_close})
        return ha
