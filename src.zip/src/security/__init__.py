"""
Security module
"""
