"""
Trading strategies module
"""
