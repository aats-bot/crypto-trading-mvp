"""
Trading bot worker - manages multiple client bots
"""
import asyncio
import logging
import signal
import sys
from typing import Dict, List
from datetime import datetime
import json
import os
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent.parent.parent
sys.path.append(str(project_root))

from config.settings import settings
from src.bot.trading_bot import TradingBot

# Configure logging
logging.basicConfig(
    level=getattr(logging, settings.log_level),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/trading_bot.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)


class BotWorker:
    """Worker that manages multiple trading bots"""
    
    def __init__(self):
        self.bots: Dict[str, TradingBot] = {}
        self.is_running = False
        self.shutdown_event = asyncio.Event()
        
        # Setup signal handlers
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
        
        logger.info("Bot worker initialized")
    
    def _signal_handler(self, signum, frame):
        """Handle shutdown signals"""
        logger.info(f"Received signal {signum}, initiating shutdown...")
        self.shutdown_event.set()
    
    async def start(self):
        """Start the bot worker"""
        try:
            self.is_running = True
            logger.info("Starting bot worker...")
            
            # Load client configurations
            await self._load_client_configs()
            
            # Start monitoring loop
            await self._monitoring_loop()
            
        except Exception as e:
            logger.error(f"Error starting bot worker: {e}")
            raise
        finally:
            await self._shutdown()
    
    async def _load_client_configs(self):
        """Load client configurations and start bots"""
        try:
            # For MVP, use mock client configurations
            # In production, this would load from database
            mock_clients = self._get_mock_client_configs()
            
            for client_id, config in mock_clients.items():
                await self.add_client_bot(client_id, config)
                
        except Exception as e:
            logger.error(f"Error loading client configs: {e}")
    
    def _get_mock_client_configs(self) -> Dict[str, Dict]:
        """Get mock client configurations for testing"""
        return {
            "client_001": {
                "api_key": settings.bybit_api_key or "mock_api_key",
                "api_secret": settings.bybit_api_secret or "mock_api_secret",
                "testnet": True,
                "strategy": "sma",
                "fast_period": 10,
                "slow_period": 20,
                "symbols": ["BTCUSDT"],
                "risk_per_trade": 0.02,
                "update_interval": 30,
                "risk_management": {
                    "max_position_size_usd": 500.0,
                    "max_daily_loss_usd": 50.0,
                    "stop_loss_pct": 0.02
                }
            },
            "client_002": {
                "api_key": settings.bybit_api_key or "mock_api_key",
                "api_secret": settings.bybit_api_secret or "mock_api_secret",
                "testnet": True,
                "strategy": "rsi",
                "rsi_period": 14,
                "oversold": 30,
                "overbought": 70,
                "symbols": ["ETHUSDT"],
                "risk_per_trade": 0.015,
                "update_interval": 45,
                "risk_management": {
                    "max_position_size_usd": 300.0,
                    "max_daily_loss_usd": 30.0,
                    "stop_loss_pct": 0.025
                }
            }
        }
    
    async def add_client_bot(self, client_id: str, config: Dict):
        """Add a new client bot"""
        try:
            if client_id in self.bots:
                logger.warning(f"Bot for client {client_id} already exists")
                return
            
            # Create and start bot
            bot = TradingBot(client_id, config)
            self.bots[client_id] = bot
            
            # Start bot in background
            asyncio.create_task(self._run_bot(bot))
            
            logger.info(f"Added bot for client {client_id}")
            
        except Exception as e:
            logger.error(f"Error adding bot for client {client_id}: {e}")
    
    async def remove_client_bot(self, client_id: str):
        """Remove a client bot"""
        try:
            if client_id not in self.bots:
                logger.warning(f"Bot for client {client_id} not found")
                return
            
            # Stop bot
            bot = self.bots[client_id]
            await bot.stop()
            
            # Remove from dict
            del self.bots[client_id]
            
            logger.info(f"Removed bot for client {client_id}")
            
        except Exception as e:
            logger.error(f"Error removing bot for client {client_id}: {e}")
    
    async def _run_bot(self, bot: TradingBot):
        """Run a single bot"""
        try:
            await bot.start()
        except Exception as e:
            logger.error(f"Error running bot {bot.client_id}: {e}")
            # Remove failed bot
            if bot.client_id in self.bots:
                del self.bots[bot.client_id]
    
    async def _monitoring_loop(self):
        """Main monitoring loop"""
        while self.is_running and not self.shutdown_event.is_set():
            try:
                # Monitor bot health
                await self._check_bot_health()
                
                # Log status
                await self._log_status()
                
                # Wait for next check or shutdown signal
                try:
                    await asyncio.wait_for(self.shutdown_event.wait(), timeout=60)
                    break  # Shutdown signal received
                except asyncio.TimeoutError:
                    continue  # Continue monitoring
                    
            except Exception as e:
                logger.error(f"Error in monitoring loop: {e}")
                await asyncio.sleep(10)
    
    async def _check_bot_health(self):
        """Check health of all bots"""
        try:
            for client_id, bot in list(self.bots.items()):
                status = bot.get_status()
                
                # Check if bot is stuck
                if status["last_update"]:
                    last_update = datetime.fromisoformat(status["last_update"])
                    time_since_update = (datetime.now() - last_update).total_seconds()
                    
                    if time_since_update > 300:  # 5 minutes
                        logger.warning(f"Bot {client_id} appears stuck, last update: {last_update}")
                
                # Check error count
                if status["error_count"] >= 5:
                    logger.warning(f"Bot {client_id} has high error count: {status['error_count']}")
                
        except Exception as e:
            logger.error(f"Error checking bot health: {e}")
    
    async def _log_status(self):
        """Log status of all bots"""
        try:
            active_bots = sum(1 for bot in self.bots.values() if bot.is_running)
            paused_bots = sum(1 for bot in self.bots.values() if bot.is_paused)
            
            logger.info(f"Bot worker status: {active_bots} active, {paused_bots} paused, "
                       f"{len(self.bots)} total bots")
            
            # Log individual bot status
            for client_id, bot in self.bots.items():
                status = bot.get_status()
                logger.debug(f"Bot {client_id}: running={status['is_running']}, "
                           f"paused={status['is_paused']}, trades={status['stats']['total_trades']}")
                
        except Exception as e:
            logger.error(f"Error logging status: {e}")
    
    async def _shutdown(self):
        """Shutdown all bots"""
        try:
            logger.info("Shutting down bot worker...")
            
            # Stop all bots
            shutdown_tasks = []
            for client_id, bot in self.bots.items():
                logger.info(f"Stopping bot for client {client_id}")
                shutdown_tasks.append(bot.stop())
            
            # Wait for all bots to stop
            if shutdown_tasks:
                await asyncio.gather(*shutdown_tasks, return_exceptions=True)
            
            self.is_running = False
            logger.info("Bot worker shutdown complete")
            
        except Exception as e:
            logger.error(f"Error during shutdown: {e}")
    
    def get_worker_status(self) -> Dict:
        """Get worker status"""
        bot_statuses = {}
        for client_id, bot in self.bots.items():
            bot_statuses[client_id] = bot.get_status()
        
        return {
            "worker_running": self.is_running,
            "total_bots": len(self.bots),
            "active_bots": sum(1 for bot in self.bots.values() if bot.is_running),
            "paused_bots": sum(1 for bot in self.bots.values() if bot.is_paused),
            "bots": bot_statuses
        }


async def main():
    """Main entry point"""
    try:
        # Create logs directory
        os.makedirs("logs", exist_ok=True)
        
        # Create and start worker
        worker = BotWorker()
        await worker.start()
        
    except KeyboardInterrupt:
        logger.info("Received keyboard interrupt")
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())

