# 🛠️ Utilitários e Helpers - Inicialização
"""
Utilitários e funções auxiliares para o sistema
Localização: /src/utils/__init__.py
"""

# Importar todos os utilitários
from .data_utils import (
    format_currency,
    format_percentage,
    format_datetime,
    parse_timeframe,
    validate_symbol,
    calculate_position_size,
)

from .crypto_utils import (
    generate_api_key,
    hash_password,
    verify_password,
    generate_secure_token,
    validate_api_credentials,
)

from .market_utils import (
    calculate_sma,
    calculate_ema,
    calculate_rsi,
    calculate_atr,
    calculate_bollinger_bands,
    detect_trend,
)

from .validation_utils import (
    validate_email,
    validate_password_strength,
    validate_trading_config,
    validate_order_params,
    sanitize_input,
)

from .file_utils import (
    ensure_directory,
    backup_file,
    load_json_config,
    save_json_config,
    compress_logs,
)

from .time_utils import (
    get_utc_timestamp,
    format_uptime,
    get_market_hours,
    is_market_open,
    get_next_candle_time,
)

from .notification_utils import (
    send_email_notification,
    send_webhook_notification,
    format_trade_notification,
    format_alert_message,
)

from .performance_utils import (
    calculate_sharpe_ratio,
    calculate_max_drawdown,
    calculate_win_rate,
    calculate_profit_factor,
    analyze_trade_distribution,
)

# Lista de todos os utilitários disponíveis
__all__ = [
    # Data Utils
    "format_currency",
    "format_percentage", 
    "format_datetime",
    "parse_timeframe",
    "validate_symbol",
    "calculate_position_size",
    
    # Crypto Utils
    "generate_api_key",
    "hash_password",
    "verify_password",
    "generate_secure_token",
    "validate_api_credentials",
    
    # Market Utils
    "calculate_sma",
    "calculate_ema",
    "calculate_rsi",
    "calculate_atr",
    "calculate_bollinger_bands",
    "detect_trend",
    
    # Validation Utils
    "validate_email",
    "validate_password_strength",
    "validate_trading_config",
    "validate_order_params",
    "sanitize_input",
    
    # File Utils
    "ensure_directory",
    "backup_file",
    "load_json_config",
    "save_json_config",
    "compress_logs",
    
    # Time Utils
    "get_utc_timestamp",
    "format_uptime",
    "get_market_hours",
    "is_market_open",
    "get_next_candle_time",
    
    # Notification Utils
    "send_email_notification",
    "send_webhook_notification",
    "format_trade_notification",
    "format_alert_message",
    
    # Performance Utils
    "calculate_sharpe_ratio",
    "calculate_max_drawdown",
    "calculate_win_rate",
    "calculate_profit_factor",
    "analyze_trade_distribution",
]