"""
Trading strategies module
"""
