"""
Dashboard module
"""