"""
Security module
"""
